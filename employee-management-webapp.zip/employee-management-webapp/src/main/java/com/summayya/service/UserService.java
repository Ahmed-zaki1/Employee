package com.summayya.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.summayya.dto.UserRegistrationDto;
import com.summayya.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
